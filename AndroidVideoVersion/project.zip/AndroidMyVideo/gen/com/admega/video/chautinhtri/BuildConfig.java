/** Automatically generated file. DO NOT MODIFY */
package com.admega.video.chautinhtri;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package com.ypyproductions.myvideo.constanst;

public interface IYoutubePlaylistConstants {
	
	public static final boolean DEBUG=true;
	
	public static final String YOUTUBE_SIGN_KEY= "YOUTUBE_SIGN_KEY";
	
	public static final String YOUTUBE_ACCOUNT="YOUTUBE_ACCOUNT";
	
	public static final boolean SHOW_ADVERTISEMENT=false;
	
	public static final String ADMOB_ID_BANNER = "ADMOB_ID_BANNER"; 
	public static final String ADMOB_ID_INTERTESTIAL = "ADMOB_ID_INTERTESTIAL"; 
	
	public static final String KEY_STATE_ID="state_id";
	public static final String KEY_CITY_ID="city_id";
	public static final String KEY_LOCATION_ID="location_id";
	public static final String KEY_NAME_FRAGMENT="name_fragment";
	public static final String KEY_ID_FRAGMENT="id_fragment";
	public static final String KEY_NAME_KEYWORD="keyword";
	public static final String KEY_EVENT_ID="event_id";
	public static final int MAX_RESULT=25;
	
	public static final String URL_LIST_PLAYLISTS="https://gdata.youtube.com/feeds/api/users/%1$s/playlists?v=2&alt=jsonc";
	public static final String URL_DETAIL_PLAYLIST="https://gdata.youtube.com/feeds/api/playlists/%1$s?v=2&alt=jsonc&max-results=25&start-index=%2$s";
	public static final String URL_VIDEO_YOUTUBE="http://youtu.be/%1$s";
	
	public static final String KEY_URL = "url";
	public static final String KEY_URL_YOUTUBE = "youtube_id";
	
}

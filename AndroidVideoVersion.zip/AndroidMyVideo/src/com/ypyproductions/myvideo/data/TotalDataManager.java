package com.ypyproductions.myvideo.data;

import java.util.ArrayList;

import com.ypyproductions.myvideo.object.PlaylistObject;
/**
 * 
 * SingletonPattern TotalDataManager to manager all datas of User
 * 
 * @author :DOBAO
 * @Email :dotrungbao@gmail.com
 * @Skype :baopfiev_k50
 * @Phone :+84983028786
 * @Date :Nov 26, 2013
 * @project :WhereMyLocation
 * @Package :com.ypyproductions.wheremylocation
 */

public class TotalDataManager {
	
	public static final String TAG = TotalDataManager.class.getSimpleName();
	
	private static TotalDataManager totalDataManager;
	private ArrayList<PlaylistObject> listPlaylistObjects;
	
	
	public static TotalDataManager getInstance(){
		if(totalDataManager==null){
			totalDataManager = new TotalDataManager();
		}
		return totalDataManager;
	}

	private TotalDataManager() {
		
	}

	public void onDestroy(){
		if(listPlaylistObjects!=null){
			listPlaylistObjects.clear();
			listPlaylistObjects=null;
		}
		totalDataManager=null;
	}

	public ArrayList<PlaylistObject> getListPlaylistObjects() {
		return listPlaylistObjects;
	}

	public void setListPlaylistObjects(ArrayList<PlaylistObject> listPlaylistObjects) {
		this.listPlaylistObjects = listPlaylistObjects;
	}
	
	
	
	
	
	
}
